# Statigo — GitHub asset pack

Ready-to-push graphics generated from your live product screens, in your app's
lavender/midnight and mint palettes.

## Files

| File | Size | Use it for |
|---|---|---|
| `showcase_collage.png` | 1600×1000 | **Top-of-README hero** — tilted 3-screen stack, most eye-catching option |
| `hero_banner.png` | 1600×500 | Slim README header banner |
| `social_preview.png` | 1200×630 | GitHub repo **Social Preview** image (Settings → Social preview) |
| `feature_explainer.png` | 1600×860 | "Features" section — 6 icon cards |
| `mockup_overview.png` | 1460×891 | Overview screen, browser-framed |
| `mockup_tasks.png` | 1460×891 | Tasks screen, browser-framed |
| `mockup_calendar.png` | 1460×891 | Calendar screen, browser-framed |
| `mockup_insights.png` | 1460×889 | Insights screen, browser-framed |
| `mockup_premium.png` | 1460×1312 | Premium screen, browser-framed |
| `mockup_signin.png` | 1460×926 | Sign-in screen, browser-framed |
| `logo_gradient.png` | 512×512 | App icon, gradient tile (good default) |
| `logo_purple.png` / `logo_teal.png` | 512×512 | Flat-color icon variants |
| `logo_icon_transparent.png` | 512×512 | Transparent-background sparkle mark for favicons/badges |

## Drop into a README

```markdown
<p align="center">
  <img src="statigo-assets/showcase_collage.png" alt="Statigo" width="100%">
</p>

## Features
<img src="statigo-assets/feature_explainer.png" alt="Statigo features">

## Screens
<img src="statigo-assets/mockup_overview.png" width="49%">
<img src="statigo-assets/mockup_tasks.png" width="49%">
```

## Repo social preview

GitHub → your repo → **Settings** → **Social preview** → upload `social_preview.png`
(1200×630, GitHub's exact recommended size).

## Repo/app icon

Use `logo_gradient.png` as the repo avatar or app icon; `logo_icon_transparent.png`
for anywhere you need just the mark on a custom background.
